import discord

def create_methods_embed():
    embed = discord.Embed(
        title="⚔️ Métodos de Ataque Disponibles",
        description="Lista de todos los métodos y su uso",
        color=discord.Color.dark_red()
    )
    
    embed.add_field(
        name="🛑 UDPPPS",
        value="`$udppps <ip> <port> <threads> <time>`\n"
              "Ataque UDP de alto paquetes por segundo",
        inline=False
    )
    
    embed.add_field(
        name="🌊 UDP Flood",
        value="`$udpflood <ip> <port> <time>`\n"
              "Ataque de inundación UDP tradicional",
        inline=False
    )
    
    embed.add_field(
        name="💀 UDP Down",
        value="`$udp-down <ip> <port> <time>`\n"
              "Ataque UDP especial para derribar objetivos",
        inline=False
    )
    
    embed.add_field(
        name="🤝 UDP Handshake",
        value="`$udphands <ip> <port> <threads> <time>`\n"
              "Ataque de handshake UDP",
        inline=False
    )
    
    embed.set_thumbnail(url="https://media.giphy.com/media/QXh9XnIJetPi0/giphy.gif")
    embed.set_footer(text="Todos los ataques tienen un cooldown de 10 segundos")
    
    return embed