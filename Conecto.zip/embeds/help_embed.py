import discord

def create_help_embed():
    embed = discord.Embed(
        title="🛡️ Comandos del Bot de Ataque",
        description="Lista de todos los comandos disponibles",
        color=discord.Color.blue()
    )
    
    embed.add_field(
        name="ℹ️ Información",
        value="`$ayuda` - Muestra este mensaje\n"
              "`$methods` - Muestra los métodos de ataque disponibles\n"
              "`$botstatus` - Muestra el estado del bot",
        inline=False
    )
    
    embed.add_field(
        name="⚔️ Ataques",
        value="`$udppps` - Ataque UDPPPS\n"
              "`$udpflood` - Ataque UDP Flood\n"
              "`$udp-down` - Ataque UDP Down\n"
              "`$udphands` - Ataque UDP Handshake\n"
              "`$stop` - Detiene todos los ataques",
        inline=False
    )
    
    embed.add_field(
        name="🔐 Administración",
        value="`$adduser <id>` - Añade un usuario autorizado (Solo owner)",
        inline=False
    )
    
    embed.set_thumbnail(url="https://media.giphy.com/media/l0HU7JI1zK6pWfUOs/giphy.gif")
    embed.set_footer(text="Bot de Protección DDoS")
    
    return embed