import discord
import os
import asyncio

async def create_status_embed():
    try:
        # Get system info
        cpu_load = os.getloadavg()[0] if hasattr(os, "getloadavg") else 0
        cpu_cores = os.cpu_count() or 1
        cpu_percent = min(cpu_load / cpu_cores, 1.0)
        
        if os.path.exists('/proc/meminfo'):
            with open('/proc/meminfo') as f:
                lines = f.readlines()
            mem_total = int([x for x in lines if "MemTotal" in x][0].split()[1]) / 1024
            mem_free = int([x for x in lines if "MemAvailable" in x][0].split()[1]) / 1024
            mem_percent = 1 - (mem_free / mem_total) if mem_total else 0
        else:
            mem_total = mem_free = mem_percent = 0
        
        # Determine status
        status = "🟢 Óptimo"
        if cpu_percent > 0.7 or mem_percent > 0.7:
            status = "🟡 Moderado"
        if cpu_percent > 0.9 or mem_percent > 0.9:
            status = "🔴 Crítico"
        
        embed = discord.Embed(
            title="📊 Estado del Bot",
            description="Información del sistema y estado actual",
            color=discord.Color.green() if status == "🟢 Óptimo" else 
                  discord.Color.orange() if status == "🟡 Moderado" else 
                  discord.Color.red()
        )
        
        embed.add_field(
            name="Estado",
            value=status,
            inline=True
        )
        
        embed.add_field(
            name="CPU",
            value=f"{cpu_load:.2f} ({cpu_percent*100:.0f}%)",
            inline=True
        )
        
        embed.add_field(
            name="RAM",
            value=f"{mem_free:.0f}MB / {mem_total:.0f}MB ({mem_percent*100:.0f}%)",
            inline=True
        )
        
        embed.set_thumbnail(url="https://media.giphy.com/media/VekcnHOwOI5So/giphy.gif")
        embed.set_footer(text="Actualizado")
        
        return embed
        
    except Exception as e:
        embed = discord.Embed(
            title="❌ Error",
            description=f"No se pudo obtener el estado del sistema: {e}",
            color=discord.Color.red()
        )
        embed.set_thumbnail(url="https://media.giphy.com/media/3o7TKSjRrfIPjeiVyY/giphy.gif")
        return embed