import discord

def create_attack_embed(method, ip, port, time, threads=None):
    embed = discord.Embed(
        title=f"🚀 Ataque {method} Iniciado",
        description=f"Enviando ataque a {ip}:{port}",
        color=discord.Color.dark_red()
    )
    
    embed.add_field(
        name="🎯 IP",
        value=f"`{ip}`",
        inline=True
    )
    
    embed.add_field(
        name="🔌 Puerto",
        value=f"`{port}`",
        inline=True
    )
    
    embed.add_field(
        name="⏱️ Duración",
        value=f"`{time} segundos`",
        inline=True
    )
    
    if threads:
        embed.add_field(
            name="🧵 Hilos",
            value=f"`{threads}`",
            inline=True
        )
    
    embed.set_thumbnail(url="https://media.giphy.com/media/HhTXt43pk1I1W/giphy.gif")
    embed.set_footer(text="Usa $stop para detener el ataque")
    
    return embed