import discord
from discord.ext import commands
import os
import asyncio
import threading
from methods.udp_attacks import UDPAttackMethods
from embeds.help_embed import create_help_embed
from embeds.methods_embed import create_methods_embed
from embeds.status_embed import create_status_embed

TOKEN_FILE = "token.txt"
if os.path.isfile(TOKEN_FILE):
    with open(TOKEN_FILE, "r") as f:
        TOKEN = f.read().strip()
else:
    import getpass
    TOKEN = getpass.getpass("Introduce el token: ")
    with open(TOKEN_FILE, "w") as f:
        f.write(TOKEN.strip())

intents = discord.Intents.all()
intents.message_content = True

bot = commands.Bot(command_prefix='$', intents=intents)

# Global attack state
attack_in_progress = False
last_attack_time = 0
cooldown_seconds = 10
current_attack_stop_event = None
owner_id = "1102257907522863175"  # Replace with the actual owner ID
authorized_users = {owner_id}

# Initialize attack methods
attack_methods = UDPAttackMethods(bot, authorized_users)

@bot.event
async def on_ready():
    print(f'Bot conectado como {bot.user.name}')
    await bot.change_presence(activity=discord.Game(name="DDoS Protection"))

@bot.command(name='ayuda')
async def ayuda(ctx):
    embed = create_help_embed()
    await ctx.send(embed=embed)

@bot.command(name='methods')
async def methods(ctx):
    embed = create_methods_embed()
    await ctx.send(embed=embed)

@bot.command(name='botstatus')
async def botstatus(ctx):
    embed = await create_status_embed()
    await ctx.send(embed=embed)

@bot.command(name='adduser')
async def adduser(ctx, user_id: str):
    if str(ctx.author.id) == owner_id:
        authorized_users.add(user_id)
        embed = discord.Embed(
            title="✅ Usuario Autorizado",
            description=f"Usuario {user_id} agregado con éxito.",
            color=discord.Color.green()
        )
        embed.set_thumbnail(url="https://media.giphy.com/media/3o7TKSjRrfIPjeiVyY/giphy.gif")
        await ctx.send(embed=embed)
    else:
        embed = discord.Embed(
            title="❌ Permiso Denegado",
            description="Solo el propietario puede agregar usuarios.",
            color=discord.Color.red()
        )
        embed.set_thumbnail(url="https://media.giphy.com/media/3o7TKSjRrfIPjeiVyY/giphy.gif")
        await ctx.send(embed=embed)

@bot.command(name='stop')
async def stop(ctx):
    global attack_in_progress, current_attack_stop_event
    if str(ctx.author.id) not in authorized_users:
        embed = discord.Embed(
            title="❌ Permiso Denegado",
            description="No tienes permiso para usar este comando.",
            color=discord.Color.red()
        )
        embed.set_thumbnail(url="https://media.giphy.com/media/3o7TKSjRrfIPjeiVyY/giphy.gif")
        await ctx.send(embed=embed)
        return
    
    if attack_in_progress and current_attack_stop_event:
        current_attack_stop_event.set()
        embed = discord.Embed(
            title="🛑 Ataque Detenido",
            description="Todos los ataques han sido detenidos",
            color=discord.Color.green()
        )
        embed.set_thumbnail(url="https://media.giphy.com/media/3o7TKSjRrfIPjeiVyY/giphy.gif")
        await ctx.send(embed=embed)
    else:
        embed = discord.Embed(
            title="⚠️ No Hay Ataques",
            description="No hay ataques en curso para detener",
            color=discord.Color.orange()
        )
        embed.set_thumbnail(url="https://media.giphy.com/media/3o7TKSjRrfIPjeiVyY/giphy.gif")
        await ctx.send(embed=embed)

# Register attack commands
bot.add_command(attack_methods.udppps)
bot.add_command(attack_methods.udpflood)
bot.add_command(attack_methods.udp_down)
bot.add_command(attack_methods.udphands)

bot.run(TOKEN)